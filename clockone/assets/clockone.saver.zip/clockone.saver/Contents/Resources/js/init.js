require({baseUrl: 'js'}, ['main']);
