require(['modules/clockone'], function (Clock) {
	var clockcontainer = document.getElementById('clockone');
	var timeSeconds = document.createElement('span');
	var timeMinutes = document.createElement('span');
	var timeHours = document.createElement('span');
	var timecontainer = document.getElementById('time');
	var clock = new Clock('foo', clockcontainer);

	timecontainer.appendChild(timeHours);
	timecontainer.appendChild(timeMinutes);
	timecontainer.appendChild(timeSeconds);


	clock.subscribe(clock, 'seconds minutes hours', function (val, type) {
		switch (type) {
		case 'seconds':
			timeSeconds.innerHTML = val < 10 ? '0' + val : val;
			break;
		case 'minutes':
			timeMinutes.innerHTML = val < 10 ? '0' + val : val;
			timeMinutes.innerHTML += '/';
			break;
		case 'hours':
			timeHours.innerHTML = val < 10 ? '0' + val : val;
			timeHours.innerHTML += '/';
			break;
		default:
			break;
		}
	});
});
